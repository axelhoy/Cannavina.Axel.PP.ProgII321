package pp.prograii321;
import java.util.ArrayList;
import java.util.List;

public class JardinColeccion {
    private List<Planta> plantas;

    public JardinColeccion() {
        plantas = new ArrayList<>();
    }
    
    public void mostrarPlantas() {
        for (Planta planta : plantas) {
            System.out.println(planta);
        }
    }

    public void podarPlantas() {
        
        for (Planta planta : plantas) {
            if (planta instanceof Arbol) {
                ((Arbol) planta).podar(); // Se castea para tratarla como un Arbol y no como una planta
            } else if (planta instanceof Arbusto) {
                ((Arbusto) planta).podar();
            } else {
                System.out.println(planta.getNombre() + " es una flor y no puede ser podada");
            }
        }
        
    }
    public void agregarPlanta(Planta planta) {
        try {
            for (Planta p : plantas) {
                if (p.getNombre().equals(planta.getNombre()) && p.getUbicacion().equals(planta.getUbicacion())) { // validacion de equals
                    throw new IllegalArgumentException("Error, la planta " + p.getNombre() + " puede estar duplicada");
                } 
            }
            plantas.add(planta);
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage()); 
        }
    }
}
