package pp.prograii321;
public class Arbusto extends Planta {
    private int densidad; // 1 a 10

    public Arbusto(String nombre, String ubicacion, EClima clima, int densidad) {
        super(nombre, ubicacion, clima);
        if (densidad < 1 || densidad > 10) {
            throw new IllegalArgumentException("Error en un arbusto, la densidad debe estar entre 1 y 10");
        }
        this.densidad = densidad;
    }

    public int getDensidad() {
        return densidad;
    }

    @Override
    public String toString() {
        return super.toString() + " Densidad del arbusto: " + densidad;
    }

    public void podar() {
        System.out.println("El arbusto " + nombre + " ha sido podado");
    }
}
