package pp.prograii321;
public class PPPrograII321 {
    public static void main(String[] args) {
        try {
            JardinColeccion jardin = new JardinColeccion();

            // Agregar plantas al sistema
            Arbol roble = new Arbol("Roble", "Norte", EClima.MONTAÑA, 15.5);

            
            Arbusto cipres = new Arbusto("Cipres", "Este", EClima.DESERTICO, 8);
            

            Flor rosa = new Flor("Tulipan", "Sur", EClima.TROPICAL, ETemporadaFlores.PRIMAVERA);
            
            jardin.agregarPlanta(roble);
            jardin.agregarPlanta(cipres);
            jardin.agregarPlanta(rosa);

            // Planta duplicada
            jardin.agregarPlanta(new Arbol("Roble", "Norte", EClima.MONTAÑA, 12.0));


            // Mostrar
            System.out.println("\nPlantas registradas:");
            jardin.mostrarPlantas();

            // Podar
            System.out.println("\nPoda de plantas:");
            jardin.podarPlantas();

        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
    

