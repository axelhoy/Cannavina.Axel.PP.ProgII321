
package pp.prograii321;

public class Arbol extends Planta {
    private double alturaMaxima;

    public Arbol(String nombre, String ubicacion, EClima clima, double alturaMaxima) {
        super(nombre, ubicacion, clima);
        this.alturaMaxima = alturaMaxima;
    }

    public double getAlturaMaxima() {
        return alturaMaxima;
    }

    @Override
    public String toString() {
        return super.toString() + " Altura maxima: " + alturaMaxima + " metros";
    }

    public void podar() {
        System.out.println("El arbol " + nombre + " ha sido podado");
    }
}
