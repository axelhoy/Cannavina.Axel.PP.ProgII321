
package pp.prograii321;

public enum EClima {
    TROPICAL,
    DESERTICO,
    TEMPLADO,
    MEDITERRANEO,
    FRIO,
    TUNDRA,
    HIELO,
    MONTAÑA
}
