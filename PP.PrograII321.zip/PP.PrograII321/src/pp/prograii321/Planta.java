package pp.prograii321;

abstract class Planta {
    protected String nombre;
    protected String ubicacion;
    protected EClima clima;

    public Planta(String nombre, String ubicacion, EClima clima) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.clima = clima;
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public EClima getClima() {
        return clima;
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + " Ubicacion: " + ubicacion + " Clima: " + clima;
    }
}
