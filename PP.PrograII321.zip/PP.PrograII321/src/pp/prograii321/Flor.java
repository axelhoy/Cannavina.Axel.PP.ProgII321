package pp.prograii321;

public class Flor extends Planta {
    private ETemporadaFlores temporada;

    public Flor(String nombre, String ubicacion, EClima clima, ETemporadaFlores temporada) {
        super(nombre, ubicacion, clima);
        this.temporada = temporada;
    }

    public ETemporadaFlores getTemporadaFlores() {
        return temporada;
    }

    @Override
    public String toString() {
        return super.toString() + " Temporada: " + temporada;
    }
}
