package pp.prograii321;
public enum ETemporadaFlores {
    PRIMAVERA,
    VERANO,
    OTOÑO,
    INVIERNO
}
